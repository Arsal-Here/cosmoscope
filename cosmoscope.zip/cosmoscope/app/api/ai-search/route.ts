import { generateObject } from "ai"
import { z } from "zod"

export const maxDuration = 30

const rectSchema = z.object({
  x: z.number().min(-1).max(2),
  y: z.number().min(-1).max(2),
  width: z.number().min(0).max(2),
  height: z.number().min(0).max(2),
})

const featureSchema = z.object({
  id: z.string(),
  label: z.string(),
  kind: z.enum(["crater", "reef", "storm", "region", "other"]),
  confidence: z.number().min(0).max(1),
  rect: rectSchema,
})

const responseSchema = z.object({
  features: z.array(featureSchema).max(6).describe("Relevant highlights within the viewport"),
})

export async function POST(req: Request) {
  const { query, viewport, time } = await req.json().catch(() => ({}))

  // Basic input guards
  if (typeof query !== "string" || !query.trim()) {
    return Response.json({ features: [] })
  }

  // Prompt the model to synthesize AOIs as normalized viewport rectangles.
  // In production: replace with proper geospatial models or retrieval pipelines.
  const { object } = await generateObject({
    model: "openai/gpt-5-mini",
    schema: responseSchema,
    prompt: [
      "You help highlight relevant regions on a deep-zoom astronomical map.",
      "Return up to 5 features as normalized viewport rectangles (x,y,width,height) in [0..1] space.",
      "Prefer 0.1–0.3 sized rectangles to keep labels readable.",
      "Rectangles must lie mostly within the current viewport bounds:",
      `viewport.x=${viewport?.x?.toFixed?.(3)} viewport.y=${viewport?.y?.toFixed?.(3)} viewport.w=${viewport?.width?.toFixed?.(3)} viewport.h=${viewport?.height?.toFixed?.(3)}`,
      `Current time index (0..100): ${typeof time === "number" ? time : 50}`,
      "Map query to feature kind when possible: crater|reef|storm|region|other.",
      `User query: ${query}`,
    ].join("\n"),
    maxOutputTokens: 600,
  })

  console.log("[v0] ai-search features:", object?.features?.length ?? 0)

  return Response.json(object ?? { features: [] })
}
