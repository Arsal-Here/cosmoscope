import dynamic from "next/dynamic"

export const dynamicParams = true

export default function Page() {
  const CosmoScopeViewer = dynamic(() => import("@/components/cosmoscope-viewer"), { ssr: false })
  return (
    <main className="min-h-dvh flex flex-col">
      <header className="border-b">
        <div className="mx-auto max-w-7xl w-full px-4 py-4 flex items-center justify-between">
          <h1 className="text-balance text-xl md:text-2xl font-semibold">CosmoScope</h1>
          <p className="text-sm text-muted-foreground">Explore the universe at every scale</p>
        </div>
      </header>
      <section className="flex-1">
        <CosmoScopeViewer />
      </section>
    </main>
  )
}
