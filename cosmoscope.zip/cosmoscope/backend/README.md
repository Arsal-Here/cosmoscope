# Django Backend

## Setup

1. Create a virtual environment and install dependencies
```bash
python -m venv .venv
. .venv/Scripts/activate  # Windows PowerShell: .venv\\Scripts\\Activate.ps1
pip install -r requirements.txt
```

2. Apply migrations and run the server
```bash
python manage.py migrate
python manage.py runserver 8000
```

## Configuration
- Environment variables (optional):
  - `DJANGO_SECRET_KEY`: Secret key
  - `DJANGO_DEBUG`: `1` to enable debug (default `1`)
  - `DJANGO_ALLOWED_HOSTS`: Comma-separated hosts (default `*`)
  - `NEXT_PUBLIC_APP_ORIGIN`: Allowed CORS origin (default `http://localhost:3000`)
  - `CORS_ALLOW_ALL`: Set `1` to allow all origins

## Endpoints
- `GET /api/health/` → readiness probe
- `POST /api/ai-search/` → mock AI search handler

#   c o s m o s c o p e  
 