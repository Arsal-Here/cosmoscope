from typing import Any
from django.http import HttpRequest
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status


@api_view(["GET"])  # Simple readiness endpoint
def health(request: HttpRequest) -> Response:
    return Response({"status": "ok"})


@api_view(["POST"])  # Placeholder for AI search
def ai_search(request: HttpRequest) -> Response:
    payload: dict[str, Any] = request.data or {}
    query: str = str(payload.get("query", "")).strip()
    if not query:
        return Response({"error": "Missing 'query'"}, status=status.HTTP_400_BAD_REQUEST)

    # Echo back a mock result structure compatible with frontend expectations
    results = [
        {"id": 1, "title": "Example result", "snippet": f"You searched for: {query}"}
    ]
    return Response({"results": results})

