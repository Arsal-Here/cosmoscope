"use client"

import type React from "react"

// OpenSeadragon deep-zoom viewer + AI search + layers + timeline + annotations

import { useEffect, useRef, useState } from "react"
import * as OpenSeadragon from "openseadragon"
import { cn } from "@/lib/utils"

type ViewportRect = { x: number; y: number; width: number; height: number }
type Feature = {
  id: string
  label: string
  kind: "crater" | "reef" | "storm" | "region" | "other"
  confidence: number
  rect: ViewportRect // normalized viewport rect [0..1], w.r.t current world
}

type Annotation = {
  id: string
  type: "pin" | "box"
  label: string
  rect: ViewportRect // for pin, use small width/height (e.g., 0.01)
}

export default function CosmoScopeViewer() {
  const containerRef = useRef<HTMLDivElement | null>(null)
  const viewerRef = useRef<OpenSeadragon.Viewer | null>(null)
  const [query, setQuery] = useState("")
  const [loading, setLoading] = useState(false)
  const [features, setFeatures] = useState<Feature[]>([])
  const [annotations, setAnnotations] = useState<Annotation[]>([])
  const [addPinMode, setAddPinMode] = useState(false)
  const [time, setTime] = useState(50) // 0..100 demo timeline
  const [layers, setLayers] = useState({
    visible: true,
    infrared: false,
    elevation: false,
  })

  const featureColor = (kind: Feature["kind"]) => {
    switch (kind) {
      case "crater":
        return "var(--color-chart-1)"
      case "reef":
        return "var(--color-chart-2)"
      case "storm":
        return "var(--color-chart-3)"
      case "region":
        return "var(--color-chart-4)"
      default:
        return "var(--color-chart-5)"
    }
  }

  // Initialize OpenSeadragon
  useEffect(() => {
    if (!containerRef.current || viewerRef.current) return

    viewerRef.current = OpenSeadragon.default({
      element: containerRef.current,
      prefixUrl: "https://openseadragon.github.io/openseadragon/images/",
      showNavigator: true,
      preserveViewport: true,
      crossOriginPolicy: "Anonymous",
      visibilityRatio: 1.0,
      minZoomImageRatio: 0.5,
      maxZoomPixelRatio: 2.0,
      zoomPerScroll: 1.2,
      animationTime: 0.9,
      // High-res demo image; swap with NASA DZI/WMTS later
      tileSources: "https://openseadragon.github.io/example-images/highsmith/highsmith.dzi",
    })

    // Click handler for adding pins
    viewerRef.current.addHandler("canvas-click", (ev: any) => {
      if (!addPinMode) return
      if (!viewerRef.current) return
      const viewportPoint = viewerRef.current.viewport.pointFromPixel(ev.position)
      // Small pin rectangle in viewport coords
      const rect: ViewportRect = {
        x: viewportPoint.x - 0.005,
        y: viewportPoint.y - 0.005,
        width: 0.01,
        height: 0.01,
      }
      const id = `ann-${Date.now()}`
      const newAnn: Annotation = { id, type: "pin", label: "Pin", rect }
      setAnnotations((prev) => [...prev, newAnn])
      setAddPinMode(false)
    })

    console.log("[v0] OpenSeadragon initialized")
  }, [addPinMode])

  // Draw overlays whenever features/annotations/layers/time change
  useEffect(() => {
    const viewer = viewerRef.current
    if (!viewer) return

    viewer.clearOverlays()

    // Layer hint overlays (demo only)
    if (layers.infrared) {
      // A translucent red tint overlay
      addOverlayRect(
        viewer,
        { x: 0.05, y: 0.05, width: 0.15, height: 0.07 },
        "IR Layer",
        "bg-[color:var(--color-chart-5)]/20",
      )
    }
    if (layers.elevation) {
      // A translucent blue tint overlay
      addOverlayRect(
        viewer,
        { x: 0.8, y: 0.1, width: 0.15, height: 0.07 },
        "Elevation Layer",
        "bg-[color:var(--color-chart-2)]/20",
      )
    }

    // AI features
    features.forEach((f) => {
      addFeatureOverlay(viewer, f)
    })

    // User annotations
    annotations.forEach((a) => {
      addAnnotationOverlay(viewer, a)
    })
  }, [features, annotations, layers, time])

  // Helper to add rectangle overlay
  function addOverlayRect(viewer: OpenSeadragon.Viewer, rect: ViewportRect, title: string, extraClassName?: string) {
    const el = document.createElement("div")
    el.className = cn(
      "rounded-md border border-primary/60",
      "text-xs px-1 py-0.5",
      "backdrop-blur-[1px]",
      extraClassName,
    )
    el.setAttribute("role", "note")
    el.setAttribute("aria-label", title)
    el.style.color = "var(--color-primary-foreground)"
    el.style.background = "color-mix(in oklch, var(--color-primary) 10%, transparent)"
    el.innerText = title

    const osdRect = new OpenSeadragon.Rect(rect.x, rect.y, rect.width, rect.height, 0)
    viewer.addOverlay({
      element: el,
      location: osdRect,
      placement: OpenSeadragon.Placement.CENTER,
      checkResize: false,
    })
  }

  function addFeatureOverlay(viewer: OpenSeadragon.Viewer, f: Feature) {
    const el = document.createElement("div")
    el.className = "rounded-md border text-[10px] leading-none"
    el.style.borderColor = featureColor(f.kind)
    el.style.color = "var(--color-foreground)"
    el.style.background = "color-mix(in oklch, var(--color-background) 70%, transparent)"
    el.style.boxShadow = "0 0 0 1px color-mix(in oklch, var(--color-foreground) 20%, transparent) inset"

    const label = document.createElement("div")
    label.className = "px-1 py-0.5"
    label.textContent = `${f.label} (${Math.round(f.confidence * 100)}%)`
    el.appendChild(label)

    const osdRect = new OpenSeadragon.Rect(f.rect.x, f.rect.y, f.rect.width, f.rect.height, 0)
    viewer.addOverlay({
      element: el,
      location: osdRect,
      placement: OpenSeadragon.Placement.CENTER,
      checkResize: false,
    })
  }

  function addAnnotationOverlay(viewer: OpenSeadragon.Viewer, a: Annotation) {
    if (a.type === "pin") {
      const el = document.createElement("div")
      el.className = "rounded-full border"
      el.style.width = "100%"
      el.style.height = "100%"
      el.style.borderColor = "var(--color-primary)"
      el.style.background = "var(--color-primary)"
      el.setAttribute("title", a.label)
      const osdRect = new OpenSeadragon.Rect(a.rect.x, a.rect.y, a.rect.width, a.rect.height, 0)
      viewer.addOverlay({
        element: el,
        location: osdRect,
        placement: OpenSeadragon.Placement.CENTER,
        checkResize: false,
      })
    } else {
      addOverlayRect(viewer, a.rect, a.label)
    }
  }

  // Submit AI search
  async function onSearchSubmit(e: React.FormEvent) {
    e.preventDefault()
    const viewer = viewerRef.current
    if (!viewer) return
    setLoading(true)
    try {
      const bounds = viewer.viewport.getBounds(true) // viewport coords
      const viewport: ViewportRect = {
        x: bounds.x,
        y: bounds.y,
        width: bounds.width,
        height: bounds.height,
      }
      console.log("[v0] AI search request:", { query, viewport })
      const res = await fetch("/api/ai-search", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ query, viewport, time }),
      })
      if (!res.ok) {
        throw new Error(`Request failed: ${res.status}`)
      }
      const data: { features: Feature[] } = await res.json()
      console.log("[v0] AI search response:", data)
      setFeatures(data.features ?? [])
    } catch (err: any) {
      console.error("[v0] AI search error:", err?.message)
    } finally {
      setLoading(false)
    }
  }

  // Simple client-only layer toggles (demo)
  function toggleLayer(name: keyof typeof layers) {
    setLayers((prev) => ({ ...prev, [name]: !prev[name] }))
  }

  return (
    <div className="h-[calc(100dvh-64px)] grid grid-rows-[auto_1fr]">
      {/* Controls */}
      <div className="border-b">
        <div className="mx-auto max-w-7xl w-full px-4 py-3 flex flex-wrap items-center gap-3">
          <form onSubmit={onSearchSubmit} className="flex items-center gap-2">
            <label htmlFor="cs-query" className="sr-only">
              Search
            </label>
            <input
              id="cs-query"
              className="h-9 w-64 md:w-96 rounded-md border bg-background px-3 text-sm"
              placeholder='Try: {"find lunar craters near the south pole"}'
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              aria-label="AI search query"
            />
            <button
              type="submit"
              className="h-9 px-3 rounded-md bg-primary text-primary-foreground text-sm disabled:opacity-50"
              disabled={loading || !query.trim()}
            >
              {loading ? "Searching..." : "Search"}
            </button>
          </form>

          {/* Layers */}
          <div className="ml-auto flex items-center gap-3">
            <fieldset className="flex items-center gap-3" aria-label="Layers">
              <label className="flex items-center gap-2 text-sm">
                <input type="checkbox" checked={layers.visible} onChange={() => toggleLayer("visible")} />
                Visible
              </label>
              <label className="flex items-center gap-2 text-sm">
                <input type="checkbox" checked={layers.infrared} onChange={() => toggleLayer("infrared")} />
                Infrared
              </label>
              <label className="flex items-center gap-2 text-sm">
                <input type="checkbox" checked={layers.elevation} onChange={() => toggleLayer("elevation")} />
                Elevation
              </label>
            </fieldset>

            {/* Add Pin */}
            <button
              type="button"
              className={cn(
                "h-9 px-3 rounded-md text-sm border",
                addPinMode ? "bg-primary text-primary-foreground border-transparent" : "bg-card text-foreground",
              )}
              aria-pressed={addPinMode}
              onClick={() => setAddPinMode((p) => !p)}
            >
              {addPinMode ? "Click on map…" : "Add Pin"}
            </button>
          </div>

          {/* Timeline */}
          <div className="w-full md:w-auto md:ml-4 flex items-center gap-3">
            <label htmlFor="cs-time" className="text-sm">
              Time
            </label>
            <input
              id="cs-time"
              type="range"
              min={0}
              max={100}
              value={time}
              onChange={(e) => setTime(Number(e.target.value))}
              className="w-full md:w-64"
              aria-label="Time-lapse slider"
            />
            <span className="text-xs text-muted-foreground w-10 text-right">{time}</span>
          </div>
        </div>
      </div>

      {/* Viewer */}
      <div className="relative">
        <div ref={containerRef} className="absolute inset-0" aria-label="Deep zoom viewer" role="application" />
        {/* Legend */}
        <div className="absolute bottom-3 left-3 rounded-md border bg-card/90 backdrop-blur px-2 py-1 text-xs">
          <div className="font-medium">Legend</div>
          <ul className="mt-1 space-y-0.5">
            <li className="flex items-center gap-2">
              <span className="inline-block h-2 w-2 rounded-sm" style={{ background: "var(--color-chart-1)" }} />
              Crater
            </li>
            <li className="flex items-center gap-2">
              <span className="inline-block h-2 w-2 rounded-sm" style={{ background: "var(--color-chart-2)" }} />
              Reef
            </li>
            <li className="flex items-center gap-2">
              <span className="inline-block h-2 w-2 rounded-sm" style={{ background: "var(--color-chart-3)" }} />
              Storm
            </li>
            <li className="flex items-center gap-2">
              <span className="inline-block h-2 w-2 rounded-sm" style={{ background: "var(--color-chart-4)" }} />
              Region
            </li>
          </ul>
        </div>
      </div>
    </div>
  )
}
